// let today = new Date(`${new Date().getMonth() + 1}/${new Date().getDate()}/${new Date().getFullYear()}`).getTime();
// let deadline = new Date("01/10/2020").getTime();
// let dayBaki = (deadline - today) / (1000 * 3600 * 24);